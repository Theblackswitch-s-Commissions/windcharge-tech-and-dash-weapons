scoreboard players operation #search tbs.ID = @s tbs.ID
scoreboard players add @s poison_timer 1
execute if score @s poison_timer matches 15.. run tag @s remove doing_a_poison_dash
summon marker ~ ~ ~ {Tags:[poison_cloud,INIT]}
execute as @e[type=marker,tag=poison_cloud,tag=INIT] run function tg:special_weapons/poison/_tick/_generated_55/with_57
particle minecraft:dust{color: [0.2, 0.5, 0.2], scale: 2} ~ ~ ~ 0.5 0.5 0.5 0 6
execute if score #3 tbs.slow_tick = #3 tbs.random_delay run playsound minecraft:block.sculk.hit master @a ~ ~ ~ 0.2 0.9
