item replace entity @s saddle with minecraft:saddle[minecraft:enchantments={"tg:internal/slam":1}]
